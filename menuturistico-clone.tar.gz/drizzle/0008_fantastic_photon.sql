ALTER TABLE `analyses` ADD `amazonAvgPrice` int;--> statement-breakpoint
ALTER TABLE `analyses` ADD `amazonProductCount` int;--> statement-breakpoint
ALTER TABLE `analyses` ADD `amazonSearchUrl` text;--> statement-breakpoint
ALTER TABLE `analyses` ADD `amazonMinPrice` int;--> statement-breakpoint
ALTER TABLE `analyses` ADD `amazonMaxPrice` int;